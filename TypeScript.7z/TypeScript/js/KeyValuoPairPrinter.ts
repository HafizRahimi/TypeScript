

class KeyValuePair <TKey, TValuo>{
    constructor(public key:TKey , public value:TValuo){}
}


class KeyValuoPairPrinter<T,U>{
    constructor(private pairs: KeyValuePair<T,U>[]){}

    print()
    {
        for(let p of this.pairs)
        {
            console.log(`${p.key} : ${p.value}`);
            
        }
    }
}