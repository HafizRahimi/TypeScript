"use strict";
exports.__esModule = true;
var model_1 = require("./model");
var DataAccess_1 = require("./DataAccess");
var service = new DataAccess_1.TodoService([]);
var task = {
    id: 5,
    name: 'task 1',
    state: model_1.TodoState.New
};
var task2 = {
    id: 6,
    name: 'task 6',
    state: model_1.TodoState.Complete
};
service.add(task);
service.add(task2);
var todos = service.getAll();
todos.forEach(function (todo) {
    console.log(todo.name + "[" + DataAccess_1.TodoService[todo.state] + "]");
});
